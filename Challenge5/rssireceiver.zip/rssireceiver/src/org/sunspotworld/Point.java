/**
 * Created by Samuel on 2014/11/2.
 */
package org.sunspotworld;

public class Point {
    int x, y;
    public Point(int _x, int _y) {
        x = _x;
        y = _y;
    }
}